package pathX.data;

/**
 *
 * @author Steven Liao
 */
public class pathXRecord 
{
    
}
