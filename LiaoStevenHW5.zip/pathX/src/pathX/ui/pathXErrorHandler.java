package pathX.ui;

import javax.swing.JFrame;
/**
 * This class provides dialog boxes to when error happens.
 *
 * @author Steven Liao
 */
public class pathXErrorHandler 
{
    // THIS WILL BE NEEDED FOR THE DIALOG BOX TO HOVER OVER
    private JFrame window;
    
    /**
     * This simple little class just needs the window.
     * 
     * @param initWindow 
     */
    public pathXErrorHandler(JFrame initWindow)
    {
        window = initWindow;
    }
    
    
}