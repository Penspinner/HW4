package pathX.file;

import pathX.ui.pathXMiniGame;

/**
 *
 * @author Steven Liao
 */
public class pathXFileManager 
{
    private pathXMiniGame game;
    
    public pathXFileManager(pathXMiniGame initGame)
    {
        game = initGame;
    }
    
    public void loadLevel()
    {
        
    }
}
