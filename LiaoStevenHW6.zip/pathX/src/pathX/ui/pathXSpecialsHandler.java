package pathX.ui;

/**
 *
 * @author Steven Liao
 */
public class pathXSpecialsHandler 
{
    // THE PATHX GAME, IT PROVIDES ACCESS TO EVERYTHING
    private pathXMiniGame game;

    /**
     * Constructor, it just keeps the game for when the events happen.
     */
    public pathXSpecialsHandler(pathXMiniGame initGame)
    {
        game = initGame;
    }
}
